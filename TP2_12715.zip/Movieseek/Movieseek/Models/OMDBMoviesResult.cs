﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Movieseek.Models
{
    public class OMDBMoviesResult
    {
        public List<Movie> Search;

        public string totalResults;

    }
}
