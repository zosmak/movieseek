﻿using Microsoft.EntityFrameworkCore;
using MovieseekAPI.Models.Db;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieseekAPI.Models
{
    public class MovieseekDbContext : DbContext
    {
        public MovieseekDbContext(DbContextOptions<MovieseekDbContext> options)
            : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Movie> Movies { get; set; }
    }
}
